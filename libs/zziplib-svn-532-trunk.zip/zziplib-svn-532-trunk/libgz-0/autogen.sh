#! /bin/sh
autoreconf --install
